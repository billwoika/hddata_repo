from setuptools import setup

setup(name='hddata',
    version='0.1',
    packages=['hddata'],
    install_requires=[
        'dockerspawner==0.11.1'
    ])