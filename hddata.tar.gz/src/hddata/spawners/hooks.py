import os
import shutil

from jupyterhub.spawner import Spawner


def permissions_pre_spawn_hook(spawner: Spawner):
    if not spawner.user.name:
        raise ValueError('Spawner Object does not have username')
    username = spawner.user.name
    user_path = os.path.join('/home', username)
    if not os.path.exists(user_path):
        os.mkdir(user_path)
        shutil.chown(user_path, user=int(1000), group=100)
        os.chmod(user_path, 0o755)
