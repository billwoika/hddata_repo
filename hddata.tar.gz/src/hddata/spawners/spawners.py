from dockerspawner import DockerSpawner

class HDDataDockerSpawner(DockerSpawner):
    def __init__(self):
        if self.user == 'grader-development':
            self.image = os.environ.get('GRADER_IMAGE')
        else:
            self.image = os.environ.get('USER_NOTEBOOK')